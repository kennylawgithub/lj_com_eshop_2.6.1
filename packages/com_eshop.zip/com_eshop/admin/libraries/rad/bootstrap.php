<?php
/**
 * Register the prefix so that the classes in RAD library can be auto-load
 */
defined('_JEXEC') or die();
JLoader::registerPrefix('RAD', dirname(__FILE__));
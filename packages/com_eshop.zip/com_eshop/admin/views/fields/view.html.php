<?php
/**
 * @version		1.6.5
 * @package		Joomla
 * @subpackage	Membership Pro
 * @author  Tuan Pham Ngoc
 * @copyright	Copyright (C) 2012 - 2014 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */
// no direct access
defined('_JEXEC') or die();
/**
 * HTML View class for OS Membership Component
 *
 * @static
 * @package		Joomla
 * @subpackage	Membership Pro
 */
class EshopViewFields extends EShopViewList
{
	
}
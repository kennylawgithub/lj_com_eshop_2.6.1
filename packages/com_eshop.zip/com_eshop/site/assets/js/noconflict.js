if (typeof(Eshop) === 'undefined') {
    var Eshop = {};
}
Eshop.jQuery = jQuery.noConflict()

